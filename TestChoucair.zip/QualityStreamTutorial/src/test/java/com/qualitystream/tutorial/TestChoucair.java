package com.qualitystream.tutorial;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestChoucair {
	
	private WebDriver driver;
	By registerLinkLocator = By.linkText("Empleos");
    By PalabraClav = By.id("search_keywords");
    By Ubicacion = By.id("search_location");
    By BotonTrab = By.className("job_types");
    
    By BotonAnalista = By.linkText("Analista de Pruebas Panam�");
    
	@Before
	public void setUp() throws Exception {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\50765\\eclipse-workspace\\QualityStreamTutorial\\src\\test\\resources\\chromedriver\\chromedriver.exe");
	     driver = new ChromeDriver ();
	     driver.manage().window().maximize();
	     driver.get("https://www.choucairtesting.com/");
	}

	@After
	public void tearDown() throws Exception {
		/*driver.quit();*/
	}

	@Test
	public void test() throws InterruptedException{
	driver.findElement(registerLinkLocator).click ();
	Thread.sleep(10000);
	
	WebElement searchbox = driver.findElement(By.name("search_keywords"));
	searchbox.sendKeys("Analista de Pruebas");
	searchbox.submit();
	WebElement searchbox_2 = driver.findElement(By.name("search_location"));
	searchbox_2.sendKeys("Panam�");
	searchbox_2.submit();
	driver.findElement(BotonTrab).click ();
	driver.findElement(BotonAnalista).click ();
	
	}

}
